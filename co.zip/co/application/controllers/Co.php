<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Co extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct()
	 {
		 parent::__construct();
		 $this->load->model('modelco');
		 
	 }
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function dashboard()
	{
		$this->check_auth();
		$data['title'] = "Dashboard";
		$data['content'] = "Dashboard";
		$this->load->view('header/header',$data);
		$this->load->view('body/dashboard',$data);
		$this->load->view('footer/footer');
	}
	public function home()
	{
		$data['title'] = "Home";
		$data['content'] = "Home";
		$this->load->view('header/header',$data);
		$this->load->view('body/home',$data);
		$this->load->view('footer/footer');
	}
	public function login()
	{
		//~ $this->check_logged_auth();
		$books = $this->modelco->getBooks();
		
		//~ print_r($books);die("=");
		$data['title'] = "Login";
		$data['content'] = "Login To Your Account";
		$this->load->view('header/header',$data);
		$this->load->view('body/login',$data);
		$this->load->view('footer/footer');
	}
	public function validate()
	{
		$validateUser = $this->modelco->login($this->input->post());
		if($validateUser)
		{
			$this->session->set_userdata('logged_in',true);
			$this->session->set_userdata('userid',$validateUser[0]['id']);
			redirect(site_url("/co/dashboard"));
		}
		else
		{
			$this->session->set_flashdata('msg', "Invalid Credentials");
			redirect(site_url("/co/login"));
		}
	}
	public function check_logged_auth()
	{
		if($this->session->userdata('logged_in'))
		{
			redirect(site_url('/co/dashboard'));
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url('co/login'));
	}
	public function check_auth()
	{
		if(!$this->session->userdata('logged_in'))
		{
			redirect(site_url('/co/login'));
		}
	}
	public function addBooks()
	{
		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['encrypt_name'] = TRUE;

        $this->load->library('upload', $config);
		$this->upload->do_upload('file');
		@unlink('./uploads/download.png');
		print_r($this->upload->data('file_name'));
	}
}
