<style>
	.invalid
	{
		color:red;
	}
	.valid
	{
		color:green;
	}
</style>
<h1><?php echo $content;?></h1>
<?=$this->session->userdata('msg');?>
<form class="form-horizontal" id="loginForm" method="POST" action="<?php echo site_url('/co/validate');?>">
  <div class="form-group">
    <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-5">
      <input type="email" class="form-control" id="emails" name="email" placeholder="Enter email" >
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Password:</label>
    <div class="col-sm-5"> 
      <input type="password" class="form-control" id="pwds" placeholder="Enter password" name="password">
    </div>
  </div>
 <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-5">
      <button type="submit" class="btn btn-default">Submit</button>
    </div>
  </div>
</form>

<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody>
		</tbody>
</table>
<script>
$(function() {
	$('#example').DataTable();
  $("#loginForm").validate({
	errorClass: "invalid",
	validClass: "success",
    rules: {
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    messages: {
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: {
		   required: "Please provide a email",
			email: "Enter Valid Email Address"
	  }
    },
    submitHandler: function(form) {
		console.log("DONE");
      form.submit();
    }
  });
});
</script>
