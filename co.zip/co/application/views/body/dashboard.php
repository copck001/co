<h1><?php echo $content;?></h1>
<form class="form-horizontal" id="loginForm" method="POST" action="<?php echo site_url('/co/addBooks');?>" enctype="multipart/form-data">
  <div class="form-group">
    <label class="control-label col-sm-2" for="email">Book Name:</label>
    <div class="col-sm-5">
      <input type="name" class="form-control" id="name" name="name" placeholder="Enter Name" >
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Upload File:</label>
    <div class="col-sm-5"> 
      <input type="file" class="form-control" id="file"  name="file">
    </div>
  </div>
 <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-5">
      <button type="submit" class="btn btn-default">Submit</button>
    </div>
  </div>
</form>
	
