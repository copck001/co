
		
		<h1><?php echo $content;?></h1>
		<?php echo site_url();?>
	
