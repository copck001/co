<!DOCTYPE HTML>
<html>
	<head>
		<title><?php echo $title;?></title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
		<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

	</head>
<body>
	<nav class="navbar navbar-inverse">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="<?php echo site_url('co/home'); ?>">CO</a>
		</div>
		<ul class="nav navbar-nav">
			<?php if($this->session->userdata('logged_in')) {?>
				 <li><a href="<?php echo site_url('co/dashboard'); ?>">Dashboard</a></li>
			<?php }else{?>
				 <li class="active"><a href="<?php echo site_url('co/home'); ?>">Home</a></li>
			<?php }?>
		</ul>
		<ul class="nav navbar-nav navbar-right">
		<?php if($this->session->userdata('logged_in')) {?>
			  <li><a href="<?php echo site_url('co/logout'); ?>"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
		<?php }else{?>
			  <li><a href="<?php echo site_url('co/login'); ?>"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		<?php }?>
		
		
		</ul>
	  </div>
	</nav>
	<div class="container">
