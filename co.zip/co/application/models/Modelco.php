<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modelco extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}
	public function login($data)
	{
		$sql = "SELECT id FROM users WHERE email='".$data['email']."' AND password='".md5($data['password'])."'";
		//~ return $sql;
		
		$query = $this->db->query($sql);
		if($query->num_rows() > 0)
		{
			return $query->result_array();
		}
		else
		{
			return FALSE;
		}
	}
	public function getBooks()
	{
		$sql = "SELECT * FROM books WHERE 1";
		//~ return $sql;
		
		$query = $this->db->query($sql);
		if($query->num_rows() > 0)
		{
			return $query->result_array();
		}
		else
		{
			return FALSE;
		}
	}
}
